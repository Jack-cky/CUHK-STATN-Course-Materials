Insert into TEAMS values( 1, 'South Hong Kong', 30 );
Insert into TEAMS values( 2, 'Dai Lin', 28.7);
Insert into TEAMS values( 3, 'Shanghai', 27);
Insert into TEAMS values( 4, 'Men United', 29);
Insert into TEAMS values( 5, 'Old Castle', 35);
Insert into TEAMS values( 6, 'AD Millan', 29);
Insert into TEAMS values( 7, 'Tokyo Sakura', 25);
Insert into TEAMS values( 8, 'Osaka Hana', 32.4);
Insert into TEAMS values( 9, 'Curtis-Wsagor', 24);
Insert into TEAMS values( 10, 'Royal Madirid', 30 );
Insert into TEAMS values( 11, 'Byan Muni', 30 );
Insert into TEAMS values( 12, 'Chicago Cow', 24 );



