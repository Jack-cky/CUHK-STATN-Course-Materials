insert into REGIONS values( 1, 'China', 100);
insert into REGIONS values( 2, 'Japan', 30);
insert into REGIONS values( 3, 'England', 10);
insert into REGIONS values( 4, 'Brazil', 3);
insert into REGIONS values( 5, 'Spain', 1);
insert into REGIONS values( 6, 'Germany', 8);
insert into REGIONS values( 7, 'United States', 50);
insert into REGIONS values( 8, 'Italy', 9);
insert into REGIONS values( 9, 'Hong Kong', 150);
