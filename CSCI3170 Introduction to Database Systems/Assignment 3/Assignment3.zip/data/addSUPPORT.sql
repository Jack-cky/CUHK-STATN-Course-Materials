Insert into SUPPORT values ( 1, 1, 0.05 );
Insert into SUPPORT values ( 3, 1, 0.1 );
Insert into SUPPORT values ( 5, 1, 0.15 );

Insert into SUPPORT values ( 2, 2, 0.35 );
Insert into SUPPORT values ( 20, 2, 0.45 );
Insert into SUPPORT values ( 4, 2, 0.95 );

Insert into SUPPORT values ( 2, 3, 1.3 );
Insert into SUPPORT values ( 19, 3, 0.04 );
Insert into SUPPORT values ( 18, 3, 0.45 );

Insert into SUPPORT values ( 19, 4, 0.55 );
Insert into SUPPORT values ( 2, 4, 0.85 );
Insert into SUPPORT values ( 6, 4, 2.1 );

Insert into SUPPORT values ( 14, 5, 1.2 );

Insert into SUPPORT values ( 19, 6, 0.78 );
Insert into SUPPORT values ( 2, 6, 0.55 );
Insert into SUPPORT values ( 10, 6, 0.43 );
Insert into SUPPORT values ( 11, 6, 0.87 );
Insert into SUPPORT values ( 12, 6, 1.11 );

Insert into SUPPORT values ( 1, 7, 0.76 );
Insert into SUPPORT values ( 2, 7, 0.23 );
Insert into SUPPORT values ( 3, 7, 0.48 );

Insert into SUPPORT values ( 8, 8, 1.56 );
Insert into SUPPORT values ( 9, 8, 0.95 );
Insert into SUPPORT values ( 10, 8, 0.27 );
Insert into SUPPORT values ( 11, 8, 0.36 );
Insert into SUPPORT values ( 12, 8, 0.45 );
Insert into SUPPORT values ( 13, 8, 0.56 );

Insert into SUPPORT values ( 19, 9, 0.35 );
Insert into SUPPORT values ( 2, 9, 1.22 );
Insert into SUPPORT values ( 13, 9, 0.78 );
Insert into SUPPORT values ( 14, 9, 0.14 );
Insert into SUPPORT values ( 15, 9, 0.86 );


Insert into SUPPORT values ( 19, 10, 0.45 );
Insert into SUPPORT values ( 19, 11, 0.12 );





