package example;

import java.util.Scanner;
import javax.swing.JOptionPane;

class SampleDialogue
{
    public static void main(String[] args)
    {
        String answer;
        answer = JOptionPane.showInputDialog("Input PI");
        // parse/ convert the answer (which is a String) to a number (a double)
        double number;
        number = Double.parseDouble(answer);

        // re-use variable answer to store another piece of user input text
        answer = JOptionPane.showInputDialog("Input your SID");
        // parse/ convert the answer (which is a String) to a SID (an integer)
        int SID;
        SID = Integer.parseInt(answer);

        JOptionPane.showMessageDialog(null, 
               "Hi student " + SID + ", PI is " + number + ", isn't it?");

        // connect to the keyboard using class Scanner and System.in
        Scanner keyboard = new Scanner(System.in);

        // ask questions and get inputs via the console/ terminal
        System.out.print("Type a line and <Enter>: ");
        String aLineOfText = keyboard.nextLine();
        System.out.print("Type a number and <Enter>: ");
        int anIntegerNumber = keyboard.nextInt();

        System.out.println("Got " + anIntegerNumber + " after " + aLineOfText);
        // program terminates here after the last user interaction
    }

}

